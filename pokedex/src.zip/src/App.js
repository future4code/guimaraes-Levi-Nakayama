function App() {
  return (
    <div className="App">
      <h1>Pokemons</h1>
      </div>
  );
}

export default App;
